// siegeNgin Content Script - Pointing UI
(function() {
  // Prevent double injection
  if (window.__siegeNginActive) {
    // Toggle off
    const panel = document.getElementById('sn-panel');
    if (panel) panel.remove();
    window.__siegeNginActive = false;
    document.querySelectorAll('.sn-hover, .sn-selected').forEach(el => {
      el.classList.remove('sn-hover', 'sn-selected');
    });
    return;
  }
  window.__siegeNginActive = true;

  const API_BASE = 'https://teddy.bon-soleil.com/siegengin';
  let selectedEl = null;
  let hoveredEl = null;
  let panelAction = false;

  // --- CSS Selector Generator ---
  function getCSSSelector(el) {
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    let current = el;
    while (current && current.nodeType === 1 && current.tagName !== 'HTML') {
      let selector = current.tagName.toLowerCase();
      if (current.id) { parts.unshift(`#${CSS.escape(current.id)}`); break; }
      if (current.className && typeof current.className === 'string') {
        const classes = current.className.trim().split(/\s+/)
          .filter(c => !c.startsWith('sn-')).slice(0, 2);
        if (classes.length) selector += '.' + classes.map(CSS.escape).join('.');
      }
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);
        if (siblings.length > 1) selector += `:nth-of-type(${siblings.indexOf(current) + 1})`;
      }
      parts.unshift(selector);
      current = current.parentElement;
    }
    return parts.join(' > ');
  }

  // --- XPath Generator ---
  function getXPath(el) {
    if (el.id) return `//*[@id="${el.id}"]`;
    const parts = [];
    let current = el;
    while (current && current.nodeType === 1 && current.tagName !== 'HTML') {
      let tag = current.tagName.toLowerCase();
      if (current.id) { parts.unshift(`//*[@id="${current.id}"]`); break; }
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);
        if (siblings.length > 1) tag += `[${siblings.indexOf(current) + 1}]`;
      }
      parts.unshift(tag);
      current = current.parentElement;
    }
    return '//' + parts.join('/');
  }

  // --- Element Info ---
  function getElementInfo(el) {
    const tag = el.tagName.toLowerCase();
    const selector = getCSSSelector(el);
    const text = (el.textContent || '').trim().slice(0, 200);
    const attrs = {};
    for (const attr of el.attributes) {
      if (!attr.name.startsWith('sn-')) attrs[attr.name] = attr.value.slice(0, 100);
    }
    return { tag, selector, text, attributes: attrs };
  }

  // --- Ancestor Chain ---
  function getAncestorChain(el) {
    const chain = [];
    let current = el;
    while (current && current.tagName !== 'HTML') {
      chain.unshift(current);
      current = current.parentElement;
    }
    return chain;
  }

  // --- Find meaningful element ---
  const MEANINGFUL_TAGS = ['div','section','main','article','table','form','ul','ol','dl','nav','header','footer','aside','fieldset','a','span','strong','em','b','i','label','input','select','textarea','button','img','td','th','li','h1','h2','h3','h4','h5','h6','p'];
  function findMeaningful(target, precise) {
    if (precise) return (target.tagName === 'BODY' || target.tagName === 'HTML') ? null : target;
    let el = target;
    while (el && el.tagName !== 'BODY' && el.tagName !== 'HTML') {
      if (MEANINGFUL_TAGS.includes(el.tagName.toLowerCase())) return el;
      el = el.parentElement;
    }
    return null;
  }

  // --- Create Panel ---
  const panel = document.createElement('div');
  panel.id = 'sn-panel';
  panel.innerHTML = `
    <div id="sn-panel-header">
      <h3>🏰 siegeNgin</h3>
      <div id="sn-size-controls">
        <button id="sn-size-down">A-</button>
        <button id="sn-size-up">A+</button>
      </div>
      <button id="sn-panel-close">✕</button>
    </div>
    <div id="sn-selection-info">クリックで要素を選択 ✨</div>
    <div id="sn-breadcrumb"></div>
    <textarea id="sn-comment" placeholder="テディへのコメント..." rows="3"></textarea>
    <div id="sn-panel-footer">
      <button id="sn-btn-xpath">📍 XPath</button>
      <button id="sn-btn-send">🧸 テディに送信</button>
    </div>
    <div id="sn-speech"></div>
    <div id="sn-resize-handle"></div>
  `;
  document.body.appendChild(panel);

  // --- Font size control ---
  let baseSize = parseInt(localStorage.getItem('sn_font_size') || '14');
  panel.style.setProperty('--sn-base-size', baseSize + 'px');
  
  document.getElementById('sn-size-up').onmousedown = (e) => {
    e.stopPropagation();
    panelAction = true;
    setTimeout(() => panelAction = false, 100);
    baseSize = Math.min(baseSize + 2, 24);
    panel.style.setProperty('--sn-base-size', baseSize + 'px');
    localStorage.setItem('sn_font_size', baseSize);
  };
  document.getElementById('sn-size-down').onmousedown = (e) => {
    e.stopPropagation();
    panelAction = true;
    setTimeout(() => panelAction = false, 100);
    baseSize = Math.max(baseSize - 2, 10);
    panel.style.setProperty('--sn-base-size', baseSize + 'px');
    localStorage.setItem('sn_font_size', baseSize);
  };

  // --- Panel drag ---
  const header = document.getElementById('sn-panel-header');
  let dragging = false, dragX = 0, dragY = 0;
  
  function onDragMove(e) {
    panel.style.left = (e.clientX - dragX) + 'px';
    panel.style.top = (e.clientY - dragY) + 'px';
    e.preventDefault();
  }
  function onDragEnd(e) {
    dragging = false;
    window.removeEventListener('mousemove', onDragMove, true);
    window.removeEventListener('mouseup', onDragEnd, true);
  }
  header.addEventListener('mousedown', (e) => {
    if (e.target.id === 'sn-panel-close') return;
    dragging = true;
    const rect = panel.getBoundingClientRect();
    dragX = e.clientX - rect.left;
    dragY = e.clientY - rect.top;
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    panel.style.left = rect.left + 'px';
    panel.style.top = rect.top + 'px';
    window.addEventListener('mousemove', onDragMove, true);
    window.addEventListener('mouseup', onDragEnd, true);
    e.preventDefault();
  });

  // --- Panel resize (bottom-left corner) ---
  const resizeHandle = document.getElementById('sn-resize-handle');
  let resizing = false;
  
  resizeHandle.addEventListener('mousedown', (e) => {
    e.stopPropagation();
    e.preventDefault();
    resizing = true;
    panelAction = true;
    const startX = e.clientX;
    const startY = e.clientY;
    const rect = panel.getBoundingClientRect();
    const startW = rect.width;
    const startH = rect.height;
    const startLeft = rect.left;
    // Switch to left/top positioning if not already
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    panel.style.left = rect.left + 'px';
    panel.style.top = rect.top + 'px';
    
    function onResizeMove(e) {
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      // bottom-right: width grows rightward, height grows downward
      const newW = Math.max(240, startW + dx);
      const newH = Math.max(200, startH + dy);
      panel.style.width = newW + 'px';
      panel.style.height = newH + 'px';
      e.preventDefault();
    }
    function onResizeEnd() {
      resizing = false;
      setTimeout(() => panelAction = false, 100);
      // Save size
      localStorage.setItem('sn_panel_w', panel.style.width);
      localStorage.setItem('sn_panel_h', panel.style.height);
      window.removeEventListener('mousemove', onResizeMove, true);
      window.removeEventListener('mouseup', onResizeEnd, true);
    }
    window.addEventListener('mousemove', onResizeMove, true);
    window.addEventListener('mouseup', onResizeEnd, true);
  });

  // Restore saved size
  const savedW = localStorage.getItem('sn_panel_w');
  const savedH = localStorage.getItem('sn_panel_h');
  if (savedW) panel.style.width = savedW;
  if (savedH) panel.style.height = savedH;

  // --- Breadcrumb splitter drag ---
  const breadcrumb = document.getElementById('sn-breadcrumb');
  const selInfo = document.getElementById('sn-selection-info');
  const commentEl = document.getElementById('sn-comment');

  breadcrumb.addEventListener('mousedown', (e) => {
    // Only drag on the breadcrumb background, not on crumbs
    if (e.target.classList.contains('crumb')) return;
    e.stopPropagation();
    e.preventDefault();
    panelAction = true;
    const startY = e.clientY;
    const startInfoH = selInfo.offsetHeight;
    const startCommentH = commentEl.offsetHeight;

    function onSplitMove(e) {
      const dy = e.clientY - startY;
      const newInfoH = Math.max(40, startInfoH + dy);
      const newCommentH = Math.max(40, startCommentH - dy);
      selInfo.style.height = newInfoH + 'px';
      selInfo.style.flex = 'none';
      commentEl.style.height = newCommentH + 'px';
      commentEl.style.flex = 'none';
      e.preventDefault();
    }
    function onSplitEnd() {
      setTimeout(() => panelAction = false, 100);
      localStorage.setItem('sn_info_h', selInfo.style.height);
      localStorage.setItem('sn_comment_h', commentEl.style.height);
      window.removeEventListener('mousemove', onSplitMove, true);
      window.removeEventListener('mouseup', onSplitEnd, true);
    }
    window.addEventListener('mousemove', onSplitMove, true);
    window.addEventListener('mouseup', onSplitEnd, true);
  });

  // Restore saved split
  const savedInfoH = localStorage.getItem('sn_info_h');
  const savedCommentH = localStorage.getItem('sn_comment_h');
  if (savedInfoH) { selInfo.style.height = savedInfoH; selInfo.style.flex = 'none'; }
  if (savedCommentH) { commentEl.style.height = savedCommentH; commentEl.style.flex = 'none'; }

  // --- Panel close ---
  document.getElementById('sn-panel-close').onmousedown = () => {
    panelAction = true;
    panel.remove();
    window.__siegeNginActive = false;
    document.querySelectorAll('.sn-hover, .sn-selected').forEach(el => {
      el.classList.remove('sn-hover', 'sn-selected');
    });
  };

  // --- Update selection display ---
  function updateDisplay() {
    const info = document.getElementById('sn-selection-info');
    const bc = document.getElementById('sn-breadcrumb');
    if (!selectedEl) {
      info.innerHTML = 'クリックで要素を選択 ✨';
      bc.innerHTML = '';
      return;
    }
    const ei = getElementInfo(selectedEl);
    info.innerHTML = `
      <div class="tag-line"><span class="tag">${ei.tag}</span>${ei.attributes.id ? `<span style="color:#6a5a8a;font-size:0.7rem;">#${ei.attributes.id}</span>` : ''}</div>
      <span class="selector">${ei.selector}</span>
      ${ei.text ? `<div class="text-preview">${ei.text.slice(0, 200)}</div>` : ''}
    `;
    // Breadcrumb (from body, max 8 nearest)
    let chain = getAncestorChain(selectedEl);
    if (chain.length > 8) {
      chain = [chain[0], ...chain.slice(-7)]; // body + last 7
    }
    bc.innerHTML = chain.map((ancestor, i) => {
      const tag = ancestor.tagName.toLowerCase();
      const id = ancestor.id ? `#${ancestor.id}` : '';
      const isActive = ancestor === selectedEl;
      return `<span class="crumb${isActive ? ' active' : ''}" data-idx="${i}">${tag}${id}</span>`;
    }).join('<span class="sep">›</span>');

    bc.querySelectorAll('.crumb').forEach((crumb, i) => {
      crumb.onmousedown = (e) => {
        e.stopPropagation();
        panelAction = true;
        setTimeout(() => panelAction = false, 100);
        const newEl = chain[i];
        if (newEl && newEl.tagName !== 'BODY') {
          selectedEl.classList.remove('sn-selected');
          selectedEl = newEl;
          selectedEl.classList.add('sn-selected');
          updateDisplay();
        }
      };
    });
  }

  // --- Block hover/click on panel ---
  panel.addEventListener('mouseover', (e) => e.stopPropagation(), true);
  panel.addEventListener('mouseout', (e) => e.stopPropagation(), true);
  panel.addEventListener('click', (e) => { e.stopPropagation(); e.preventDefault(); }, true);

  // --- Hover ---
  document.addEventListener('mouseover', (e) => {
    if (panel.contains(e.target)) return;
    const target = findMeaningful(e.target, false);
    if (!target) return;
    if (hoveredEl && hoveredEl !== target) hoveredEl.classList.remove('sn-hover');
    if (!target.classList.contains('sn-selected')) target.classList.add('sn-hover');
    hoveredEl = target;
  }, true);

  document.addEventListener('mouseout', (e) => {
    if (hoveredEl) { hoveredEl.classList.remove('sn-hover'); hoveredEl = null; }
  }, true);

  // --- Click (capture: intercept before page handlers) ---
  document.addEventListener('click', (e) => {
    // Let panel clicks through normally
    if (panel.contains(e.target) || panelAction) return;
    if (!window.__siegeNginActive) return;
    if (dragging || resizing) return;
    e.preventDefault();
    e.stopImmediatePropagation();

    const target = findMeaningful(e.target, e.shiftKey);
    if (!target) return;
    target.classList.remove('sn-hover');

    if (selectedEl) selectedEl.classList.remove('sn-selected');
    selectedEl = target;
    selectedEl.classList.add('sn-selected');
    updateDisplay();
  }, true);

  // --- XPath copy ---
  document.getElementById('sn-btn-xpath').onmousedown = (e) => {
    e.stopPropagation();
    panelAction = true;
    setTimeout(() => panelAction = false, 100);
    if (!selectedEl) return;
    navigator.clipboard.writeText(getXPath(selectedEl));
    showSpeech('XPath コピーしました 📋');
  };

  // --- Send to Teddy ---
  document.getElementById('sn-btn-send').onmousedown = async (e) => {
    e.stopPropagation();
    panelAction = true;
    setTimeout(() => panelAction = false, 100);
    if (!selectedEl) { showSpeech('要素を選択してね'); return; }
    const ei = getElementInfo(selectedEl);
    const comment = document.getElementById('sn-comment').value.trim();
    const data = {
      url: location.href,
      timestamp: new Date().toISOString(),
      comment: comment || null,
      tag: ei.tag,
      selector: ei.selector,
      text: ei.text?.slice(0, 500),
      attributes: ei.attributes,
    };
    try {
      // Flush old response
      await fetch(`${API_BASE}/api/response`).catch(() => {});
      showSpeech('受け取ったよ！考え中... 🤔');
      const resp = await fetch(`${API_BASE}/api/point`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const result = await resp.json();
      if (result.ok) {
        document.getElementById('sn-comment').value = '';
        pollForResponse();
      }
    } catch (e) {
      showSpeech('送信失敗: ' + e.message);
    }
  };

  // --- Speech bubble ---
  function showSpeech(msg) {
    const el = document.getElementById('sn-speech');
    el.textContent = msg;
    el.style.display = 'block';
    clearTimeout(el._timer);
    el._timer = setTimeout(() => { el.style.display = 'none'; }, 10000);
  }

  // --- Poll for response ---
  function pollForResponse(attempts = 0) {
    if (attempts > 30) { showSpeech('ちょっと時間かかってるかも... 💦'); return; }
    setTimeout(async () => {
      try {
        const resp = await fetch(`${API_BASE}/api/response`);
        if (resp.status === 200) {
          const data = await resp.json();
          if (data.message) { showSpeech(data.message); return; }
        }
      } catch (e) {}
      pollForResponse(attempts + 1);
    }, 1000);
  }

})();
